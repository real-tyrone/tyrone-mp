    institution_key = {
        icon = "path/to/icon"                                                           # path to graphical icon
        background_texture = "path/to/background_texture"                               # path to background texture
        modifier = {}                                                                   # modifier on country for having adopted this institution
    }
